/**
 * Popup UI Logic
 */

let extractedCookies = null;
const CURRENT_VERSION = '1.1.0';

// DOM элементы
const domainSelect = document.getElementById('domain');
const customDomainInput = document.getElementById('customDomain');
const webAppUrlInput = document.getElementById('webAppUrl');
const autoExtractBtn = document.getElementById('autoExtractBtn');
const extractBtn = document.getElementById('extractBtn');
const copyBtn = document.getElementById('copyBtn');
const sendBtn = document.getElementById('sendBtn');
const statusDiv = document.getElementById('status');
const cookiePreview = document.getElementById('cookiePreview');
const statsDiv = document.getElementById('stats');
const totalCountSpan = document.getElementById('totalCount');
const cfCountSpan = document.getElementById('cfCount');
const updateNotification = document.getElementById('updateNotification');
const updateText = document.getElementById('updateText');
const downloadUpdateBtn = document.getElementById('downloadUpdateBtn');

// Показать/скрыть custom domain input
domainSelect.addEventListener('change', function() {
  if (this.value === 'other') {
    customDomainInput.style.display = 'block';
  } else {
    customDomainInput.style.display = 'none';
  }
});

// Автоматическое получение cookies
autoExtractBtn.addEventListener('click', async function() {
  const domain = domainSelect.value === 'other'
    ? customDomainInput.value.trim()
    : domainSelect.value;

  if (!domain) {
    showStatus('Укажите домен', 'error');
    return;
  }

  autoExtractBtn.disabled = true;
  autoExtractBtn.innerHTML = '<span class="spinner"></span> Открываем вкладку...';
  showStatus('Открываем czbooks.net в новой вкладке...', 'info');

  try {
    // Пытаемся получить URL новеллы из Web App
    let targetUrl = `https://${domain}`;
    const webAppUrl = webAppUrlInput.value.trim();

    console.log('🔍 DEBUG: Начинаем автоматическое извлечение cookies');
    console.log('📍 Domain:', domain);
    console.log('🌐 Web App URL:', webAppUrl);

    if (webAppUrl) {
      try {
        console.log('📡 Запрашиваем список новелл...');
        const novelsResponse = await fetch(`${webAppUrl}/api/novels?active_only=true`);
        console.log('📡 Response status:', novelsResponse.status);

        if (novelsResponse.ok) {
          const novelsData = await novelsResponse.json();
          console.log('📚 Получено новелл:', novelsData.novels?.length || 0);

          if (novelsData.success && novelsData.novels) {
            const czBooksNovel = novelsData.novels.find(n =>
              n.source_type === 'czbooks.net' ||
              n.source_type === 'czbooks' ||
              (n.source_url && n.source_url.includes('czbooks.net'))
            );

            if (czBooksNovel) {
              console.log('✅ Найдена новелла:', czBooksNovel);
              if (czBooksNovel.source_url) {
                targetUrl = czBooksNovel.source_url;
                console.log('🎯 Открываем конкретную новеллу:', targetUrl);
              }
            } else {
              console.log('⚠️ Новелла czbooks не найдена, используем главную страницу');
            }
          }
        } else {
          console.error('❌ Ошибка получения новелл:', novelsResponse.statusText);
        }
      } catch (e) {
        console.error('❌ Не удалось получить URL новеллы:', e);
        console.log('📍 Используем главную страницу:', targetUrl);
      }
    }

    // Открываем страницу в новой вкладке
    console.log('📂 Открываем вкладку:', targetUrl);
    const tab = await chrome.tabs.create({
      url: targetUrl,
      active: false
    });
    console.log('✅ Вкладка открыта, ID:', tab.id);

    showStatus('Ожидание Cloudflare challenge (~15 секунд)...', 'info');

    // Ждем 15 секунд для прохождения Cloudflare
    console.log('⏳ Ждем 15 секунд...');
    await new Promise(resolve => setTimeout(resolve, 15000));
    console.log('✅ Ожидание завершено');

    // Извлекаем cookies через background script
    console.log('🍪 Запрашиваем cookies для домена:', domain);
    const response = await chrome.runtime.sendMessage({
      action: 'getCookies',
      domain: domain
    });
    console.log('🍪 Response:', response);

    if (response.success && response.cookies) {
      console.log('📊 Статистика cookies:');
      console.log('  - Всего:', response.cookies.count);
      console.log('  - Cloudflare:', response.cookies.cloudflareCount);
      console.log('  - cf_clearance:', response.cookies.cloudflareCookies?.find(c => c.name === 'cf_clearance') ? '✅' : '❌');
      console.log('  - __cf_bm:', response.cookies.cloudflareCookies?.find(c => c.name === '__cf_bm') ? '✅' : '❌');
    }

    if (response.success && response.cookies.count > 0) {
      extractedCookies = response.cookies;
      displayCookies(response.cookies);
      showStatus(`✅ Успешно! Найдено ${response.cookies.count} cookies`, 'success');

      console.log('🗑️ Закрываем вкладку:', tab.id);
      // Закрываем вкладку
      await chrome.tabs.remove(tab.id);

      // Автоматически отправляем в Web App
      if (webAppUrl) {
        console.log('📤 Отправляем cookies в Web App...');
        await autoSendToWebApp(webAppUrl);
      }
    } else {
      console.error('❌ Мало cookies!');
      console.log('💡 Оставляем вкладку открытой для проверки');
      showStatus(`⚠️ Найдено мало cookies (${response.cookies ? response.cookies.count : 0}). Попробуйте еще раз.`, 'error');
      // Не закрываем вкладку, пусть пользователь проверит
    }
  } catch (error) {
    showStatus(`❌ Ошибка: ${error.message}`, 'error');
  } finally {
    autoExtractBtn.disabled = false;
    autoExtractBtn.innerHTML = '<span class="icon">🚀</span> Автоматически получить Cookies';
  }
});

// Извлечь cookies
extractBtn.addEventListener('click', async function() {
  const domain = domainSelect.value === 'other'
    ? customDomainInput.value.trim()
    : domainSelect.value;

  if (!domain) {
    showStatus('Укажите домен', 'error');
    return;
  }

  // Показываем загрузку
  extractBtn.disabled = true;
  extractBtn.innerHTML = '<span class="spinner"></span> Извлекаем...';

  try {
    // Отправляем запрос в background script
    const response = await chrome.runtime.sendMessage({
      action: 'getCookies',
      domain: domain
    });

    if (response.success) {
      extractedCookies = response.cookies;
      displayCookies(response.cookies);
      showStatus(`✅ Успешно! Найдено ${response.cookies.count} cookies`, 'success');
    } else {
      showStatus(`❌ Ошибка: ${response.error}`, 'error');
    }
  } catch (error) {
    showStatus(`❌ Ошибка: ${error.message}`, 'error');
  } finally {
    extractBtn.disabled = false;
    extractBtn.innerHTML = '<span class="icon">🔍</span> Извлечь Cookies';
  }
});

// Копировать в буфер
copyBtn.addEventListener('click', async function() {
  if (!extractedCookies) return;

  try {
    await navigator.clipboard.writeText(extractedCookies.cookieString);
    showStatus('✅ Cookies скопированы в буфер обмена!', 'success');

    // Анимация кнопки
    const originalText = copyBtn.innerHTML;
    copyBtn.innerHTML = '<span class="icon">✅</span> Скопировано!';
    setTimeout(() => {
      copyBtn.innerHTML = originalText;
    }, 2000);
  } catch (error) {
    showStatus(`❌ Ошибка копирования: ${error.message}`, 'error');
  }
});

// Отправить в Web App
sendBtn.addEventListener('click', async function() {
  if (!extractedCookies) return;

  const webAppUrl = webAppUrlInput.value.trim();
  if (!webAppUrl) {
    showStatus('Укажите URL Web App', 'error');
    return;
  }

  sendBtn.disabled = true;
  sendBtn.innerHTML = '<span class="spinner"></span> Отправляем...';

  try {
    const response = await chrome.runtime.sendMessage({
      action: 'sendToWebApp',
      cookies: extractedCookies.cookieString,
      webAppUrl: webAppUrl
    });

    if (response.success) {
      showStatus('✅ Cookies успешно отправлены в Web App!', 'success');
    } else {
      showStatus(`❌ Ошибка отправки: ${response.error}`, 'error');
    }
  } catch (error) {
    showStatus(`❌ Ошибка: ${error.message}`, 'error');
  } finally {
    sendBtn.disabled = false;
    sendBtn.innerHTML = '<span class="icon">📤</span> Отправить в Web App';
  }
});

/**
 * Отображение извлеченных cookies
 */
function displayCookies(cookies) {
  // Показываем preview
  cookiePreview.textContent = cookies.cookieString;
  cookiePreview.style.display = 'block';

  // Показываем статистику
  totalCountSpan.textContent = cookies.count;
  cfCountSpan.textContent = cookies.cloudflareCount;
  statsDiv.style.display = 'flex';

  // Показываем кнопки действий
  copyBtn.style.display = 'block';
  sendBtn.style.display = 'block';
}

/**
 * Показать статус сообщение
 */
function showStatus(message, type = 'info') {
  statusDiv.textContent = message;
  statusDiv.className = `status ${type}`;
  statusDiv.style.display = 'block';

  // Автоматически скрываем через 5 секунд
  setTimeout(() => {
    statusDiv.style.display = 'none';
  }, 5000);
}

/**
 * Автоматическая отправка в Web App
 */
async function autoSendToWebApp(webAppUrl) {
  if (!extractedCookies) return;

  showStatus('Отправляем cookies в Web App...', 'info');

  try {
    const response = await chrome.runtime.sendMessage({
      action: 'sendToWebApp',
      cookies: extractedCookies.cookieString,
      webAppUrl: webAppUrl
    });

    if (response.success) {
      showStatus('✅ Cookies успешно отправлены в Web App!', 'success');
      return true;
    } else {
      showStatus(`❌ Ошибка отправки: ${response.error}`, 'error');
      return false;
    }
  } catch (error) {
    showStatus(`❌ Ошибка: ${error.message}`, 'error');
    return false;
  }
}

/**
 * Загрузить сохраненные настройки
 */
if (chrome.storage && chrome.storage.sync) {
  chrome.storage.sync.get(['webAppUrl'], function(result) {
    if (result.webAppUrl) {
      webAppUrlInput.value = result.webAppUrl;
    }
  });
}

/**
 * Сохранять настройки при изменении
 */
webAppUrlInput.addEventListener('change', function() {
  if (chrome.storage && chrome.storage.sync) {
    chrome.storage.sync.set({ webAppUrl: this.value });
  }
});

/**
 * Проверка обновлений
 */
async function checkForUpdates() {
  const webAppUrl = webAppUrlInput.value.trim();
  if (!webAppUrl) return;

  try {
    const response = await fetch(`${webAppUrl}/api/extension/version`);
    if (response.ok) {
      const data = await response.json();
      if (data.version && compareVersions(data.version, CURRENT_VERSION) > 0) {
        // Новая версия доступна
        updateText.textContent = `Версия ${data.version} доступна (у вас ${CURRENT_VERSION})`;
        updateNotification.style.display = 'block';

        // Обработчик кнопки скачивания
        downloadUpdateBtn.onclick = function() {
          window.open(`${webAppUrl}/download-extension`, '_blank');
        };
      }
    }
  } catch (e) {
    // Тихо игнорируем ошибки проверки обновлений
    console.log('Не удалось проверить обновления:', e);
  }
}

/**
 * Сравнение версий (semver)
 * Возвращает: 1 если v1 > v2, -1 если v1 < v2, 0 если равны
 */
function compareVersions(v1, v2) {
  const parts1 = v1.split('.').map(Number);
  const parts2 = v2.split('.').map(Number);

  for (let i = 0; i < 3; i++) {
    if (parts1[i] > parts2[i]) return 1;
    if (parts1[i] < parts2[i]) return -1;
  }
  return 0;
}

// Проверяем обновления при открытии popup
checkForUpdates();
