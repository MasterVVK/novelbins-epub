# Icons for Browser Extension

Browser extensions require icons in three sizes:
- **icon16.png** - 16x16px (toolbar icon)
- **icon48.png** - 48x48px (extension management page)
- **icon128.png** - 128x128px (Chrome Web Store)

## How to create icons

### Option 1: Generate placeholder icons (quick)

```bash
# Create simple colored placeholder icons
convert -size 16x16 xc:'#667eea' icon16.png
convert -size 48x48 xc:'#667eea' icon48.png
convert -size 128x128 xc:'#667eea' icon128.png
```

### Option 2: Use a design tool

1. Open Figma/Photoshop/GIMP
2. Create a 128x128px canvas
3. Design a cookie icon (🍪) with purple gradient
4. Export as PNG in three sizes: 16, 48, 128

### Option 3: Online icon generator

Use: https://www.favicon-generator.org/
1. Upload your base image
2. Download generated icons
3. Rename to icon16.png, icon48.png, icon128.png

## Design Guidelines

**Theme:** Cookie + Code
**Colors:**
- Primary: #667eea (purple)
- Secondary: #764ba2 (darker purple)
- Accent: White

**Symbol:**
- Cookie emoji (🍪) or
- Cookie icon with code brackets {🍪}

## Temporary Solution

For development, create simple colored squares:

```bash
cd /home/user/novelbins-epub/browser_extension/icons/

# Create placeholder using ImageMagick
convert -size 16x16 -background '#667eea' -fill white -gravity center -pointsize 10 label:'C' icon16.png
convert -size 48x48 -background '#667eea' -fill white -gravity center -pointsize 30 label:'🍪' icon48.png
convert -size 128x128 -background '#667eea' -fill white -gravity center -pointsize 80 label:'🍪' icon128.png
```

Or use online tool: https://img.icons8.com/
