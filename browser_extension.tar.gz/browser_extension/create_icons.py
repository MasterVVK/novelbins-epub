#!/usr/bin/env python3
"""
Создание простых PNG иконок для Browser Extension
Использует PIL/Pillow для генерации базовых иконок
"""

try:
    from PIL import Image, ImageDraw, ImageFont
    import os

    def create_icon(size, filename):
        """Создать иконку с градиентом и текстом"""
        # Создаем изображение с градиентом
        img = Image.new('RGB', (size, size))
        draw = ImageDraw.Draw(img)

        # Рисуем градиент фона
        for y in range(size):
            # Цвета: #667eea -> #764ba2
            r = int(102 + (118 - 102) * y / size)
            g = int(126 + (75 - 126) * y / size)
            b = int(234 + (162 - 234) * y / size)
            draw.rectangle([(0, y), (size, y+1)], fill=(r, g, b))

        # Добавляем текст "C" (Cookie)
        try:
            font_size = int(size * 0.6)
            # Пытаемся использовать системный шрифт
            try:
                font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", font_size)
            except:
                font = ImageFont.load_default()
        except:
            font = None

        text = "C"
        if font:
            bbox = draw.textbbox((0, 0), text, font=font)
            text_width = bbox[2] - bbox[0]
            text_height = bbox[3] - bbox[1]
        else:
            text_width = size // 2
            text_height = size // 2

        x = (size - text_width) // 2
        y = (size - text_height) // 2

        # Рисуем текст
        draw.text((x, y), text, fill='white', font=font)

        # Сохраняем
        img.save(filename)
        print(f"✓ Создана иконка: {filename} ({size}x{size})")

    # Создаем директорию если нет
    icons_dir = os.path.dirname(__file__) + '/icons'
    os.makedirs(icons_dir, exist_ok=True)

    # Создаем иконки разных размеров
    create_icon(16, f'{icons_dir}/icon16.png')
    create_icon(48, f'{icons_dir}/icon48.png')
    create_icon(128, f'{icons_dir}/icon128.png')

    print("\n✅ Все иконки успешно созданы!")
    print(f"📁 Расположение: {icons_dir}/")

except ImportError:
    print("❌ Pillow не установлен!")
    print("\nУстановите Pillow:")
    print("  pip install Pillow")
    print("\nИли создайте иконки вручную:")
    print("  1. Любой PNG редактор")
    print("  2. Размеры: 16x16, 48x48, 128x128")
    print("  3. Цвет фона: #667eea")
    print("  4. Текст: белая буква 'C'")
