# Browser Extension - Информация о версиях

## Текущая версия: 1.1.0

### Как обновить версию расширения:

1. **Обновите версию в 3 местах:**

   ```bash
   # 1. manifest.json
   "version": "1.2.0"

   # 2. popup.js
   const CURRENT_VERSION = '1.2.0';

   # 3. popup.html (footer)
   <small style="color: #999; font-size: 10px;">v1.2.0</small>
   ```

2. **Обновите API endpoint:**

   ```python
   # web_app/app/api/novels.py
   @novels_bp.route('/extension/version', methods=['GET'])
   def get_extension_version():
       return jsonify({
           'success': True,
           'version': '1.2.0',
           'changelog': [
               'Новая фича 1',
               'Исправление бага 2',
               # ...
           ],
           'download_url': '/download-extension'
       })
   ```

3. **Пересоберите архив:**

   ```bash
   cd /home/user/novelbins-epub
   tar -czf browser_extension.tar.gz browser_extension/
   cp browser_extension.tar.gz web_app/app/static/browser_extension.tar.gz
   ```

4. **Создайте RELEASE NOTES:**

   ```bash
   # Создайте файл VERSION_X.X.X_RELEASE.md
   # Опишите изменения
   ```

---

## История версий

### v1.1.0 (2025-10-13)
**Исправления:**
- Ошибка `chrome.storage.sync`
- Увеличено время ожидания до 15 секунд
- Автоматическое открытие конкретной страницы новеллы
- Поддержка обоих типов source_type

**Новое:**
- Система версионирования
- Автоматическая проверка обновлений
- API endpoint `/api/extension/version`
- Отображение версии в popup

### v1.0.0 (2025-10-13)
**Первый релиз:**
- Автоматическое извлечение cookies
- Открытие czbooks.net в фоновой вкладке
- Автоматическая отправка в Web App
- Автоматическое определение новеллы

---

## Структура файлов

```
browser_extension/
├── manifest.json          # Версия: "version": "1.1.0"
├── popup.html            # Footer: v1.1.0
├── popup.js              # CURRENT_VERSION = '1.1.0'
├── background.js         # Service worker
├── icons/
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
├── README.md
├── QUICK_START.md
└── VERSION_INFO.md       # Этот файл
```

---

## API Endpoints

### GET /api/extension/version
Возвращает информацию о текущей версии:

```json
{
  "success": true,
  "version": "1.1.0",
  "changelog": [
    "Изменение 1",
    "Изменение 2"
  ],
  "download_url": "/download-extension"
}
```

---

## Проверка версии

### В расширении:
Откройте popup → внизу показывается: `v1.1.0`

### Через API:
```bash
curl http://192.168.0.58:5001/api/extension/version
```

### В manifest.json:
```bash
grep version browser_extension/manifest.json
```

---

## Semver (Semantic Versioning)

Формат: `MAJOR.MINOR.PATCH`

- **MAJOR:** Несовместимые изменения API (1.0.0 → 2.0.0)
- **MINOR:** Новая функциональность, обратно совместимая (1.0.0 → 1.1.0)
- **PATCH:** Исправления багов (1.0.0 → 1.0.1)

**Примеры:**
- `1.0.0` → `1.0.1` - исправлен баг
- `1.0.0` → `1.1.0` - добавлена новая фича
- `1.0.0` → `2.0.0` - breaking changes

---

## Автоматическое уведомление

Расширение проверяет обновления при каждом открытии popup:

```javascript
// popup.js
async function checkForUpdates() {
  const response = await fetch(`${webAppUrl}/api/extension/version`);
  const data = await response.json();

  if (compareVersions(data.version, CURRENT_VERSION) > 0) {
    // Показать уведомление
    updateNotification.style.display = 'block';
  }
}
```

Пользователь видит:
```
🔄 Доступно обновление!
Версия 1.2.0 доступна (у вас 1.1.0)
[Скачать обновление]
```

---

## Best Practices

### Перед релизом:
1. ✅ Обновить версию в 3 местах
2. ✅ Обновить API endpoint
3. ✅ Протестировать локально
4. ✅ Пересобрать архив
5. ✅ Обновить RELEASE NOTES
6. ✅ Проверить что Web App показывает новую версию

### После релиза:
1. ✅ Проверить автоматическое уведомление в старой версии
2. ✅ Убедиться что ссылка на скачивание работает
3. ✅ Протестировать установку новой версии

---

**Последнее обновление:** 2025-10-13
