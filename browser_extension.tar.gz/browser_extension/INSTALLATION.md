# Установка Browser Extension

**Быстрая инструкция по установке Novelbins Cookie Extractor**

---

## Шаг 1: Подготовка иконок (опционально)

Расширение требует иконки для работы. Есть два варианта:

### Вариант A: Временные иконки (быстро)

Создайте простые цветные квадраты:

```bash
cd /home/user/novelbins-epub/browser_extension/icons/

# Если установлен ImageMagick:
convert -size 16x16 -background '#667eea' -fill white -gravity center -pointsize 10 label:'C' icon16.png
convert -size 48x48 -background '#667eea' -fill white -gravity center -pointsize 30 label:'C' icon48.png
convert -size 128x128 -background '#667eea' -fill white -gravity center -pointsize 80 label:'C' icon128.png
```

Или скачайте любые PNG иконки размером 16x16, 48x48, 128x128 и переименуйте их.

### Вариант B: Пропустить (расширение будет работать с предупреждением)

Chrome покажет предупреждение о missing icons, но функциональность сохранится.

---

## Шаг 2: Загрузка расширения в Chrome

### 1. Откройте Chrome Extensions

Введите в адресной строке:
```
chrome://extensions/
```

Или:
- Меню Chrome → Extensions → Manage Extensions
- Или нажмите `Ctrl+Shift+E`

### 2. Включите Developer Mode

В правом верхнем углу найдите переключатель **"Developer mode"** и включите его.

### 3. Load Unpacked

1. Нажмите кнопку **"Load unpacked"** (Загрузить распакованное)
2. Выберите папку:
   ```
   /home/user/novelbins-epub/browser_extension/
   ```
3. Нажмите **"Select Folder"**

### 4. Расширение установлено!

Вы увидите карточку расширения:
```
┌─────────────────────────────────────┐
│ Novelbins Cookie Extractor          │
│ ID: abc123...                        │
│ Version: 1.0.0                       │
│                                      │
│ [Details] [Remove] [Errors]         │
└─────────────────────────────────────┘
```

---

## Шаг 3: Закрепление расширения (рекомендуется)

Чтобы расширение всегда было под рукой:

1. Нажмите на иконку **пазла** (Extensions) в панели Chrome
2. Найдите **"Novelbins Cookie Extractor"**
3. Нажмите на **булавку** (pin icon)

Теперь иконка расширения будет всегда видна в панели инструментов.

---

## Шаг 4: Настройка Web App URL

При первом запуске расширения:

1. Кликните на иконку расширения
2. В поле **"Web App URL"** укажите:
   ```
   http://192.168.0.58:5001
   ```
3. URL автоматически сохранится для следующих запусков

---

## Шаг 5: Тестирование

### Проверка работы расширения

1. **Откройте czbooks.net**:
   ```
   https://czbooks.net
   ```

2. **Дождитесь Cloudflare challenge** (~5 секунд)
   - Страница покажет "Checking your browser..."
   - Затем загрузится нормально

3. **Откройте расширение**:
   - Кликните на иконку в панели Chrome

4. **Извлеките cookies**:
   - Нажмите кнопку **"Извлечь Cookies"**
   - Вы должны увидеть:
     ```
     ✅ Успешно! Найдено 12 cookies

     [Cookies preview: cf_clearance=xxx...]

     [12 Всего cookies] [3 Cloudflare]
     ```

5. **Отправьте в Web App**:
   - Нажмите **"Отправить в Web App"**
   - Должно появиться:
     ```
     ✅ Cookies успешно отправлены в Web App!
     ```

### Проверка в Web App

1. Откройте Web App:
   ```
   http://192.168.0.58:5001/new-novel
   ```

2. Поле **"Cookies для обхода Cloudflare"** должно быть заполнено автоматически

---

## Устранение неполадок

### Проблема: "Load unpacked" не активна

**Решение:** Включите Developer mode в `chrome://extensions/`

---

### Проблема: "Icons missing" при загрузке

**Симптом:**
```
❌ Could not load icon 'icons/icon16.png'
```

**Решение:**
1. Создайте иконки (см. Шаг 1)
2. Или игнорируйте (функциональность не пострадает)

---

### Проблема: "0 cookies найдено"

**Причины:**
1. Не дождались Cloudflare challenge
2. Открыли расширение на другой вкладке (не czbooks.net)

**Решение:**
1. Убедитесь что вы на странице `czbooks.net`
2. Подождите пока Cloudflare challenge пройдет (~5 секунд)
3. Попробуйте снова "Извлечь Cookies"

---

### Проблема: "Failed to fetch" при отправке в Web App

**Причины:**
1. Web App не запущен
2. Неверный URL
3. Web App не доступен с вашего устройства

**Решение:**
1. Проверьте что Web App запущен:
   ```bash
   # На сервере
   python run_web.py
   ```

2. Проверьте доступность в браузере:
   ```
   http://192.168.0.58:5001
   ```

3. Убедитесь что URL в расширении правильный:
   ```
   http://192.168.0.58:5001
   ```

4. Проверьте firewall (должен разрешать подключения к порту 5001)

---

### Проблема: CORS error при отправке cookies

**Симптом в Console:**
```
Access to fetch at 'http://192.168.0.58:5001/api/...' from origin 'chrome-extension://...'
has been blocked by CORS policy
```

**Решение:**
Добавьте в Web App поддержку CORS для расширения.

В `web_app/app/__init__.py`:

```python
from flask_cors import CORS

def create_app():
    app = Flask(__name__)

    # Enable CORS for browser extension
    CORS(app, resources={
        r"/api/cloudflare-auth/*": {
            "origins": ["chrome-extension://*"]
        }
    })

    return app
```

Установите flask-cors:
```bash
pip install flask-cors
```

---

## Альтернатива: Ручное копирование

Если расширение не работает, используйте ручной способ:

1. Откройте `czbooks.net`
2. Дождитесь Cloudflare challenge
3. Нажмите `F12`
4. Перейдите на вкладку **"Application"**
5. Слева: **Cookies → https://czbooks.net**
6. Скопируйте cookies вручную:
   ```
   cf_clearance=xxx; __cf_bm=yyy; _cfuvid=zzz
   ```
7. Вставьте в форму Web App

---

## Удаление расширения

Если нужно удалить:

1. Откройте `chrome://extensions/`
2. Найдите "Novelbins Cookie Extractor"
3. Нажмите **"Remove"**
4. Подтвердите удаление

---

## Обновление расширения

После изменений в коде:

1. Откройте `chrome://extensions/`
2. Найдите "Novelbins Cookie Extractor"
3. Нажмите кнопку **обновления** (↻)
4. Расширение перезагрузится с новыми изменениями

---

## Проверка прав доступа

Расширение запрашивает следующие права:

| Permission | Зачем нужно |
|------------|-------------|
| `cookies` | Чтение cookies с czbooks.net |
| `tabs` | Определение текущей вкладки |
| `activeTab` | Доступ к активной вкладке |
| `https://czbooks.net/*` | Доступ к cookies czbooks.net |
| `http://192.168.0.58:5001/*` | Отправка cookies в Web App |

Все права необходимы для работы расширения.

---

## Дополнительная информация

### Логи и отладка

**Background Service Worker:**
1. `chrome://extensions/`
2. Найдите расширение
3. Кликните **"service worker"**
4. Откроется Console с логами

**Popup UI:**
1. Откройте расширение
2. Правый клик на popup → **"Inspect"**
3. Откроется DevTools для popup

### Документация

- **README.md** - Полная документация расширения
- **CLOUDFLARE_AUTOMATION_OPTIONS.md** - Сравнение всех вариантов автоматизации
- **WEB_APP_CLOUDFLARE_SOLUTION.md** - Решение для Web App

---

## Готово! 🎉

Теперь вы можете автоматически извлекать Cloudflare cookies одной кнопкой!

**Использование:**
1. Откройте czbooks.net
2. Дождитесь Cloudflare challenge (~5 сек)
3. Кликните на расширение
4. Нажмите "Извлечь Cookies"
5. Нажмите "Отправить в Web App"
6. Готово!

**Время:** ~5 секунд вместо 10
**Автоматизация:** 95%

---

**Автор:** Claude Code Assistant
**Дата:** 2025-10-13
**Версия:** 1.0.0
