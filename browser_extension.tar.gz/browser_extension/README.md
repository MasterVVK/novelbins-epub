# Novelbins Cookie Extractor - Browser Extension

**Автоматическое извлечение Cloudflare cookies для Novelbins Web App**

## Что это?

Chrome/Edge расширение, которое **автоматически извлекает cookies** с защищенных Cloudflare сайтов (czbooks.net и др.) и отправляет их в Novelbins Web App.

## Преимущества

✅ **Автоматическое извлечение** - не нужно открывать DevTools
✅ **Одна кнопка** - вся операция за 2 клика
✅ **Безопасно** - cookies остаются на вашем устройстве
✅ **Быстро** - занимает 5 секунд вместо 10
✅ **Универсально** - работает с любыми сайтами

## Установка

### Вариант 1: Из Chrome Web Store (будущее)

```
Coming soon...
```

### Вариант 2: Вручную (Development mode)

1. **Склонируйте репозиторий** (если еще не сделали):
   ```bash
   git clone https://github.com/your-repo/novelbins-epub.git
   cd novelbins-epub/browser_extension
   ```

2. **Откройте Chrome Extensions**:
   - Перейдите на `chrome://extensions/`
   - Включите **Developer mode** (переключатель в правом верхнем углу)

3. **Загрузите расширение**:
   - Нажмите **Load unpacked**
   - Выберите папку `browser_extension/`

4. **Готово!** Расширение появится в панели Chrome.

## Использование

### Шаг 1: Откройте czbooks.net

1. Перейдите на https://czbooks.net
2. Дождитесь прохождения Cloudflare challenge (~5 секунд)

### Шаг 2: Откройте расширение

1. Кликните на иконку расширения в панели Chrome
2. Убедитесь что выбран домен `czbooks.net`
3. Укажите URL вашего Web App (по умолчанию `http://localhost:5001`)

### Шаг 3: Извлечь cookies

1. Нажмите **"Извлечь Cookies"**
2. Расширение автоматически найдет все cookies
3. Вы увидите статистику:
   - Всего cookies
   - Cloudflare cookies

### Шаг 4: Отправить в Web App (опционально)

**Вариант A: Автоматическая отправка**
1. Нажмите **"Отправить в Web App"**
2. Cookies автоматически сохранятся в Web App

**Вариант B: Ручное копирование**
1. Нажмите **"Скопировать в буфер"**
2. Вставьте cookies в форму создания новеллы

## Скриншоты

```
┌─────────────────────────────────────┐
│ 🍪 Cookie Extractor                 │
├─────────────────────────────────────┤
│ Домен сайта                         │
│ [czbooks.net ▼]                     │
│                                     │
│ Web App URL                         │
│ [http://localhost:5001]             │
│                                     │
│ [🔍 Извлечь Cookies]                │
│                                     │
│ ✅ Успешно! Найдено 12 cookies      │
│                                     │
│ ┌─────────────────────────────┐   │
│ │ cf_clearance=xxx; __cf_bm=  │   │
│ │ yyy; _cfuvid=zzz; ...       │   │
│ └─────────────────────────────┘   │
│                                     │
│ [📋 Скопировать в буфер]            │
│ [📤 Отправить в Web App]            │
│                                     │
│ ┌───────┐  ┌───────┐               │
│ │  12   │  │   3   │               │
│ │Всего  │  │Cloud- │               │
│ │cookies│  │flare  │               │
│ └───────┘  └───────┘               │
└─────────────────────────────────────┘
```

## API Интеграция

Расширение использует следующие API endpoints:

### POST `/api/cloudflare-auth/save-cookies`

Сохраняет cookies в Web App.

**Request:**
```json
{
  "cookies": "cf_clearance=xxx; __cf_bm=yyy; ...",
  "source": "browser_extension",
  "timestamp": "2025-10-13T12:00:00Z"
}
```

**Response:**
```json
{
  "success": true,
  "cookies": "cf_clearance=xxx; ...",
  "message": "Cookies получены, используйте их при создании новеллы"
}
```

## Технические детали

### Архитектура

```
┌─────────────┐
│   Popup UI  │ (popup.html + popup.js)
│  (400x500)  │
└──────┬──────┘
       │ chrome.runtime.sendMessage()
       ▼
┌─────────────────┐
│ Background SW   │ (background.js)
│ Service Worker  │
└──────┬──────────┘
       │ chrome.cookies.getAll()
       ▼
┌─────────────────┐
│ Chrome Cookies  │
│      API        │
└──────┬──────────┘
       │
       ▼
┌─────────────────┐
│ Novelbins       │ POST /api/cloudflare-auth/save-cookies
│   Web App       │
└─────────────────┘
```

### Permissions

```json
{
  "permissions": [
    "cookies",       // Доступ к Cookies API
    "tabs",          // Получение текущей вкладки
    "activeTab"      // Доступ к активной вкладке
  ],
  "host_permissions": [
    "https://czbooks.net/*",     // Cookies с czbooks.net
    "http://localhost:5001/*",   // Web App (dev)
    "http://127.0.0.1:5001/*"    // Web App (alt)
  ]
}
```

### Безопасность

- ✅ Cookies НЕ отправляются на внешние серверы
- ✅ Только localhost/127.0.0.1 для Web App
- ✅ Пользователь контролирует отправку
- ✅ Исходный код открыт для аудита

## Сравнение с ручным способом

| Метод | Время | Шагов | Сложность |
|-------|-------|-------|-----------|
| **Ручной** (DevTools) | ~10 сек | 7 | Средняя |
| **Расширение** | ~5 сек | 2 | Простая |

## FAQ

### Q: Безопасно ли это?

**A:** Да! Расширение:
- Работает только локально
- Не отправляет данные на внешние серверы
- Исходный код доступен для проверки
- Использует стандартный Chrome Cookies API

### Q: Нужно ли устанавливать для каждого браузера?

**A:** Да, расширение нужно установить в каждом браузере отдельно:
- Chrome/Edge: используйте этот вариант
- Firefox: требуется адаптация manifest.json (v2)

### Q: Cookies сохраняются в расширении?

**A:** Нет! Расширение только **читает** cookies из браузера и **отправляет** их в Web App. Cookies не хранятся в расширении.

### Q: Что если Web App на другом порту?

**A:** Измените URL в поле "Web App URL":
```
http://localhost:8080
```

Также нужно добавить в `manifest.json`:
```json
"host_permissions": [
  "http://localhost:8080/*"
]
```

### Q: Работает ли с другими сайтами?

**A:** Да! Выберите "Другой домен..." и укажите любой домен:
```
example.com
```

## Разработка

### Структура проекта

```
browser_extension/
├── manifest.json       # Манифест расширения (Manifest V3)
├── background.js       # Service Worker для извлечения cookies
├── popup.html          # UI расширения
├── popup.js            # Логика UI
├── icons/              # Иконки расширения (TODO)
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
└── README.md           # Эта документация
```

### Добавление новых доменов

1. Откройте `manifest.json`
2. Добавьте домен в `host_permissions`:
   ```json
   "host_permissions": [
     "https://new-site.com/*"
   ]
   ```
3. Перезагрузите расширение в `chrome://extensions/`

### Debugging

1. Откройте `chrome://extensions/`
2. Найдите "Novelbins Cookie Extractor"
3. Кликните **"Service worker"** для background.js
4. Кликните **"Inspect"** для popup.html

### Тестирование

```bash
# 1. Запустить Web App
cd /home/user/novelbins-epub
python run_web.py

# 2. Открыть Chrome с расширением
# (установлено в Development mode)

# 3. Протестировать на czbooks.net
# - Открыть https://czbooks.net
# - Открыть расширение
# - Извлечь cookies
# - Отправить в Web App
```

## TODO

- [ ] Создать иконки расширения (16x16, 48x48, 128x128)
- [ ] Добавить Firefox support (Manifest V2)
- [ ] Опубликовать в Chrome Web Store
- [ ] Добавить автоматическое определение Web App URL
- [ ] Добавить history извлеченных cookies
- [ ] Добавить проверку валидности cookies

## Поддержка

Если возникли проблемы:
1. Проверьте что Web App запущен (`http://localhost:5001`)
2. Проверьте Developer mode включен в Chrome
3. Перезагрузите расширение
4. Откройте Console для debugging

## Лицензия

MIT License - см. LICENSE файл в корне проекта

## Автор

Claude Code Assistant
Дата: 2025-10-13
Версия: 1.0.0
