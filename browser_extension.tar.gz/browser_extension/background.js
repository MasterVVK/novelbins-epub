/**
 * Background Service Worker
 * Обрабатывает запросы на извлечение cookies
 */

// Слушаем сообщения от popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getCookies') {
    extractCookies(request.domain)
      .then(cookies => sendResponse({ success: true, cookies }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true; // Асинхронный ответ
  }

  if (request.action === 'sendToWebApp') {
    sendCookiesToWebApp(request.cookies, request.webAppUrl)
      .then(() => sendResponse({ success: true }))
      .catch(error => sendResponse({ success: false, error: error.message }));
    return true;
  }
});

/**
 * Извлечение cookies для указанного домена
 */
async function extractCookies(domain) {
  try {
    console.log('🍪 [Background] Извлекаем cookies для домена:', domain);

    // Получаем все cookies для домена
    const allCookies = await chrome.cookies.getAll({ domain });
    console.log('🍪 [Background] Получено cookies:', allCookies.length);

    // Фильтруем только Cloudflare cookies
    const cloudflareCookies = allCookies.filter(cookie =>
      cookie.name === 'cf_clearance' ||
      cookie.name === '__cf_bm' ||
      cookie.name === '_cfuvid' ||
      cookie.name.startsWith('cf_')
    );
    console.log('🔐 [Background] Cloudflare cookies:', cloudflareCookies.length);

    // Логируем найденные Cloudflare cookies
    cloudflareCookies.forEach(cookie => {
      console.log(`  - ${cookie.name}: ${cookie.value.substring(0, 20)}...`);
    });

    // Формируем строку в формате: name1=value1; name2=value2
    const cookieString = allCookies
      .map(cookie => `${cookie.name}=${cookie.value}`)
      .join('; ');

    console.log('📝 [Background] Cookie string length:', cookieString.length);

    return {
      cookieString,
      cookies: allCookies,
      cloudflareCookies,
      count: allCookies.length,
      cloudflareCount: cloudflareCookies.length
    };
  } catch (error) {
    console.error('❌ [Background] Ошибка извлечения cookies:', error);
    throw error;
  }
}

/**
 * Отправка cookies в Web App
 */
async function sendCookiesToWebApp(cookieString, webAppUrl) {
  try {
    // Сначала пытаемся найти новеллу с czbooks.net
    let novelId = null;
    try {
      const novelsResponse = await fetch(`${webAppUrl}/api/novels?active_only=true`);
      if (novelsResponse.ok) {
        const novelsData = await novelsResponse.json();
        if (novelsData.success && novelsData.novels) {
          // Ищем новеллу с czbooks (несколько вариантов)
          const czBooksNovel = novelsData.novels.find(n =>
            n.source_type === 'czbooks.net' ||
            n.source_type === 'czbooks' ||
            (n.source_url && n.source_url.includes('czbooks.net'))
          );
          if (czBooksNovel) {
            novelId = czBooksNovel.id;
            console.log('Найдена новелла czbooks.net, ID:', novelId);
          }
        }
      }
    } catch (e) {
      console.log('Не удалось найти новеллу, сохраняем cookies глобально:', e);
    }

    // Отправляем cookies (с novel_id если найден)
    const response = await fetch(`${webAppUrl}/api/cloudflare-auth/save-cookies`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        cookies: cookieString,
        source: 'browser_extension',
        timestamp: new Date().toISOString(),
        novel_id: novelId  // Добавляем novel_id если найден
      })
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Ошибка отправки cookies в Web App:', error);
    throw error;
  }
}

/**
 * Копирование в буфер обмена (вспомогательная функция)
 */
async function copyToClipboard(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch (error) {
    console.error('Ошибка копирования:', error);
    return false;
  }
}
